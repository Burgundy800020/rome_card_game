from kivymd.app import MDApp
from kivy.properties import StringProperty,ListProperty,BooleanProperty,NumericProperty
from kivy.metrics import dp
from kivy.clock import Clock,mainthread
from kivy.graphics.texture import Texture
from kivy.uix.screenmanager import ScreenManager,Screen
from kivymd.uix.boxlayout import MDBoxLayout
from kivymd.uix.widget import MDWidget
import libs.engine as engine

app=MDApp.get_running_app()

class LifeBar(MDBoxLayout):
    reversed=BooleanProperty(False)
    state=ListProperty([True for i in range(10)])

    def __init__(self,**kwargs):
        super(LifeBar,self).__init__(**kwargs)
        Clock.schedule_once(self.on_state)

    def on_state(self,*args):
        self.clear_widgets()
        state=self.state if self.reversed else self.state[::-1]
        if self.reversed:self.add_widget(MDWidget())
        for life in state:
            dot=MDWidget(size_hint=(None,None),size=(dp(12),dp(12)),radius=dp(6),md_bg_color=(0,1,0,1) if life else (1,0,0,1))
            self.add_widget(dot)

class Card(ScreenManager):
    number=NumericProperty()
    name=StringProperty()

    def __init__(self,**kwargs):
        super(Card,self).__init__(**kwargs)

class GameScreen(Screen):
    code=StringProperty()
    
    def __init__(self,**kwargs):
        super(GameScreen,self).__init__(**kwargs)
        app.client.on("setCharacterName")(lambda data:self.setCharacterName(data))
        app.client.on("setCardState")(lambda data:self.setCardState(data))

    def initialize(self,code):
        self.code=code

    @mainthread
    def setCharacterName(self,data):
        for side in ("player","opponent"):
            image=engine.getImage(data[side])
            texture=Texture.create(size=(image.shape[1],image.shape[0]),colorfmt="rgba")
            texture.blit_buffer(image.tobytes(),bufferfmt="ubyte",colorfmt="rgba")
            self.ids[f"{side}Picture"].texture=texture
            self.ids[f"{side}Picture"].tooltip_text=data[side]
    
    @mainthread
    def setCardState(self,data):
        if "playerCards" in data:
            for card in data["playerCards"]:
                pass
        elif "opponentCards" in data:
            card=Card()
            self.ids["opponentCards"].clear_widgets()
            for i in range(int(data["opponentCards"])):
                self.ids["opponentCards"].add_widget(card)