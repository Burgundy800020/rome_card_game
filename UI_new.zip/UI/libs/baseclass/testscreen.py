import os.path
print(os.path.isfile("Images/card.png"))